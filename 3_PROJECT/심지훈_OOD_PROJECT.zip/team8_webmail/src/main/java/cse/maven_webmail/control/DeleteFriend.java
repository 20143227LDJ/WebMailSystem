/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cse.maven_webmail.control;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author jihun
 */
@WebServlet(name = "DeleteFriend", urlPatterns = {"/DeleteFriend"})
public class DeleteFriend extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
 try (PrintWriter out = response.getWriter()) {
            final String JdbcDriver = "com.mysql.cj.jdbc.Driver";
            // serverTimezone을 설정하는게 책과 다른 부분임.
            final String JdbcUrl = "jdbc:mysql:///james?serverTimezone=Asia/Seoul";
            final String User = "team1";
            final String Password = "wlgns852";

            try {
                
                Class.forName(JdbcDriver);

                
                Connection conn = DriverManager.getConnection(JdbcUrl, User, Password);

                
                String sql = "delete from addr_book where friend_email=?";
                PreparedStatement pstmt = conn.prepareStatement(sql);

               
                request.setCharacterEncoding("UTF-8");  // 한글 인식
                
                String friend = request.getParameter("friend_email");
               
                if (!(friend == null) && !friend.equals("")) {

                    pstmt.setString(1, friend);
                    
                    
                    pstmt.executeUpdate();
                }
               
                pstmt.close();
                conn.close();

                response.sendRedirect("addr_book.jsp");

            } catch (IOException | ClassNotFoundException | SQLException ex) {
                out.println("오류가 발생했습니다. (발생 오류 : " + ex.getMessage()
                        + ")");
                out.println("<br/><a href=\"index.jsp\">초기 화면으로 가기</a>");
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
